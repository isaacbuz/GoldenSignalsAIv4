class BaseAgent:
    """Base class for all agents."""
    def __init__(self, name: str = "BaseAgent"):
        self.name = name

    def analyze(self, *args, **kwargs):
        raise NotImplementedError("analyze() must be implemented by subclasses.")
