module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        fintech: {
          DEFAULT: '#0d1117',
          accent: '#00d97e',
          panel: '#181b23',
          border: '#23272e',
        },
      },
    },
  },
  plugins: [],
}
