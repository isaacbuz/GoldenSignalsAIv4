import React, { useState } from "react";
import type { AnalysisResult } from "./signalTypes";
import { Panel } from "./ui/panel";
import { Button } from "./ui/button";

export default function TickerAnalysisPanel() {
  const [ticker, setTicker] = useState("TSLA");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);

  async function analyze() {
    setLoading(true);
    const res = await fetch(`/api/analyze?ticker=${ticker}`);
    const data = await res.json();
    setResult(data);
    setLoading(false);
  }

  return (
    <Panel className="max-w-xl mx-auto">
      <h2 className="text-lg font-semibold mb-4">Analyze a Ticker</h2>
      <div className="flex gap-4 items-center mb-6">
        <input
          className="bg-fintech-panel px-2 py-1 rounded text-white border border-fintech-border focus:outline-none focus:ring-2 focus:ring-fintech-accent"
          value={ticker}
          onChange={(e) => setTicker(e.target.value.toUpperCase())}
          placeholder="Enter ticker (e.g. TSLA)"
        />
        <Button onClick={analyze} disabled={loading}>
          {loading ? "Analyzing..." : "Analyze"}
        </Button>
      </div>
      {result && (
        <Panel className="mt-2 bg-fintech border-fintech-border space-y-3">
          <h3 className="text-xl font-bold">Recommendation</h3>
          <p><strong>Strategy:</strong> {result.strategy}</p>
          <p><strong>Entry:</strong> ${result.entry} | <strong>Exit:</strong> ${result.exit}</p>
          <p><strong>Confidence:</strong> {result.confidence}%</p>
          <p><strong>Explanation:</strong> {result.explanation}</p>
          <h4 className="text-lg mt-4 font-semibold">Supporting Signals</h4>
          <ul className="list-disc ml-6">
            {Object.entries(result.supporting_signals || {}).map(([name, agent]: any, idx) => (
              <li key={idx}><strong>{name}:</strong> {agent.explanation}</li>
            ))}
          </ul>
        </Panel>
      )}
    </Panel>
  );
}