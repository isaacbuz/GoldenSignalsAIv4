import React from "react";
import { Home, BarChart2, List, RefreshCcw, Settings } from "lucide-react";
import Link from "next/link";
import ThemeToggle from "./ThemeToggle";

const nav = [
  { href: "/", label: "Home", icon: <Home size={18} /> },
  { href: "/analytics", label: "Analytics", icon: <BarChart2 size={18} /> },
  { href: "/logs", label: "Logs", icon: <List size={18} /> },
  { href: "/replay", label: "Replay", icon: <RefreshCcw size={18} /> },
  { href: "/settings", label: "Settings", icon: <Settings size={18} /> },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-fintech text-white">
      {/* Sidebar */}
      <aside className="w-56 bg-fintech-panel border-r border-fintech-border flex flex-col py-6 px-4 gap-2">
        <div className="text-2xl font-bold mb-8 tracking-tight text-fintech-accent">GoldenSignalsAI</div>
        <nav className="flex flex-col gap-2">
          {nav.map(({ href, label, icon }) => (
            <Link key={href} href={href} className="flex items-center gap-2 px-3 py-2 rounded hover:bg-fintech-border transition-colors">
              {icon}
              <span className="text-base">{label}</span>
            </Link>
          ))}
        </nav>
        <div className="mt-4">
          {/* Theme toggle */}
          <div className="flex justify-center"><ThemeToggle /></div>
        </div>
        <div className="mt-auto text-xs text-fintech-accent/60">Fintech Dashboard &copy; 2025</div>
      </aside>
      {/* Main content */}
      <main className="flex-1 p-8 bg-fintech min-h-screen overflow-y-auto">
        {children}
      </main>
    </div>
  );
}
