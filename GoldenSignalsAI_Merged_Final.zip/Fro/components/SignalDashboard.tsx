import React from "react";

export default function SignalDashboard() {
  return (
    <div className="p-4 text-white">
      <h2 className="text-2xl font-bold mb-4">📈 Signal Summary</h2>
      <p>View current strategy performance, blended signals, and agent consensus metrics.</p>
    </div>
  );
}
