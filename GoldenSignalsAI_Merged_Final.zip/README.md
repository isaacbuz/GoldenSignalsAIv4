# GoldenSignalsAI v4

Modular, AI-powered trading signal engine with live data, multiple agents, and full frontend/backend stack.

## ✅ Quickstart

### 1. Install dependencies
```
pip install -r requirements.txt
```

### 2. Start the backend
```
uvicorn main:app --reload
```

### 3. Access endpoints
- `GET /api/analyze?ticker=TSLA`
- `POST /api/train`
- `GET /api/logs`

### 4. Run tests
```
python test_analyze_pipeline.py
```

### 5. Frontend
Integrate your `frontend/` directory with your preferred React + Tailwind build system (Next.js recommended).

---

GoldenSignalsAI is designed for modular AI research, options signals, and sentiment-enhanced technical analysis.
