import React from "react";
import DashboardLayout from "../components/DashboardLayout";
import SignalDashboard from "../components/SignalDashboard";
import TickerAnalysisPanel from "../components/TickerAnalysisPanel";

export default function Home() {
  return (
    <DashboardLayout>
      <div className="flex flex-col gap-8 items-center justify-center min-h-[80vh]">
        <h1 className="text-4xl md:text-5xl font-extrabold text-neon-green mb-4 text-center drop-shadow-lg">
          GoldenSignalsAI
        </h1>
        <p className="text-lg md:text-xl text-white/80 mb-8 text-center max-w-2xl">
          The next-gen AI-powered dashboard for actionable trading signals. Analyze, visualize, and strategize with confidence.
        </p>
        <div className="w-full max-w-3xl">
          <SignalDashboard />
        </div>
        <div className="w-full max-w-3xl">
          <TickerAnalysisPanel />
        </div>
      </div>
    </DashboardLayout>
  );
}
