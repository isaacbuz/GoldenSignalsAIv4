import React from 'react';

export default function SettingsPage() {
  return (
    <div style={{ padding: 32 }}>
      <h1>Settings Page</h1>
      <p>This is a placeholder for the settings page.</p>
    </div>
  );
}
