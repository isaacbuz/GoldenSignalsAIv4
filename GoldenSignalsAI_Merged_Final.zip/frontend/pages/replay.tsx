import React from 'react';

export default function ReplayPage() {
  return (
    <div style={{ padding: 32 }}>
      <h1>Replay Page</h1>
      <p>This is a placeholder for the replay page.</p>
    </div>
  );
}
