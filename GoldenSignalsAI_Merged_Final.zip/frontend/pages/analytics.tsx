import React from "react";

export default function AnalyticsPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-fintech">
      <div className="glass-card p-8 rounded-xl border border-white/10 shadow-md">
        <h2 className="text-3xl font-bold text-neon-green mb-4 text-center">Analytics</h2>
        <p className="text-white/80 text-center">Analytics dashboard coming soon. Stay tuned for advanced signal insights and performance metrics!</p>
      </div>
    </div>
  );
}
