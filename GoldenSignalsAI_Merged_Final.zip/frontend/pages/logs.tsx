import { useEffect, useState } from "react";

type AgentData = {
  explanation: string;
  [key: string]: any;
};

type Log = {
  timestamp: string;
  ticker: string;
  blended: {
    strategy: string;
    confidence: number;
    explanation: string;
  };
  agents: {
    [name: string]: AgentData;
  };
};

export default function SignalLogDashboard() {
  const [logs, setLogs] = useState<Log[]>([]);
  const [minConfidence, setMinConfidence] = useState(0);
  const [strategyFilter, setStrategyFilter] = useState('');
  const [agentFilter, setAgentFilter] = useState('');

  async function fetchLogs() {
    const params = new URLSearchParams();
    if (minConfidence) params.append('min_confidence', minConfidence.toString());
    if (strategyFilter) params.append('strategy', strategyFilter);
    if (agentFilter) params.append('agent', agentFilter);

    const res = await fetch(`/api/logs?${params.toString()}`);
    const data = await res.json();
    setLogs(data.results);
  }

  useEffect(() => {
    fetchLogs();
  }, []);

  return (
    <div className="bg-[#12141b] min-h-screen text-white p-6">
      <h2 className="text-2xl font-bold mb-4">📊 Signal Log Dashboard</h2>
      <div className="flex gap-4 mb-6">
        <input placeholder="Strategy..." className="bg-[#1c1f26] px-2 py-1 rounded border border-gray-700" value={strategyFilter} onChange={e => setStrategyFilter(e.target.value)} />
        <input placeholder="Agent..." className="bg-[#1c1f26] px-2 py-1 rounded border border-gray-700" value={agentFilter} onChange={e => setAgentFilter(e.target.value)} />
        <input type="number" placeholder="Min Confidence" className="bg-[#1c1f26] px-2 py-1 rounded border border-gray-700 w-[150px]" value={minConfidence} onChange={e => setMinConfidence(parseInt(e.target.value))} />
        <button className="bg-green-600 px-4 py-1 rounded" onClick={fetchLogs}>Filter</button>
      </div>
      <div className="bg-[#1c1f26] border border-gray-700 rounded p-4 space-y-4">
        {logs.length === 0 && <p className="text-gray-500">No logs found. Try adjusting filters.</p>}
        {logs.map((log, i) => (
          <div key={i} className="border-b border-gray-700 pb-2">
            <p><strong>{log.timestamp}</strong> | {log.ticker} | <span className="text-green-400">{log.blended.strategy}</span> | Confidence: {log.blended.confidence}%</p>
            <p className="text-sm text-gray-400">{log.blended.explanation}</p>
            <details className="text-sm mt-1">
              <summary className="cursor-pointer text-blue-400">Agents</summary>
              <ul className="ml-4 list-disc">
                {Object.entries(log.agents).map(([name, data]) => {
                  const agentData = data as AgentData;
                  return (
                    <li key={name}><strong>{name}:</strong> {agentData.explanation}</li>
                  );
                })}
              </ul>
            </details>
          </div>
        ))}
      </div>
    </div>
  );
}
